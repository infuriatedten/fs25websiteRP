from app import create_app, db
from app.models import User
from werkzeug.security import generate_password_hash

app = create_app()

with app.app_context():
    # Optional: Clear all users first - be careful if you have real data!
    # User.query.delete()
    # db.session.commit()

    # Or skip deleting existing users and only add if username not exists:
    
    users = [
        {"username": "player1", "password": "password1", "role": "player"},
        {"username": "officer1", "password": "password2", "role": "dot_officer"},
        {"username": "supervisor1", "password": "password3", "role": "supervisor"},
        {"username": "admin1", "password": "password4", "role": "admin"},
    ]

    for u in users:
        existing_user = User.query.filter_by(username=u["username"]).first()
        if existing_user:
            print(f"User {u['username']} already exists, skipping.")
            continue
        
        user = User(
            username=u["username"],
            password=generate_password_hash(u["password"]),
            role=u["role"]
        )
        db.session.add(user)

    db.session.commit()
    print("Test users created successfully!")
