from flask import Flask, redirect, url_for, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, current_user
from flask_migrate import Migrate

# 🔁 Global declarations — THIS is what was missing
db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()

def create_app():
    app = Flask(__name__)
    
    # Config
    app.config['SECRET_KEY'] = 'super-secret-key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///fs25.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Init extensions
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    
    login_manager.login_view = 'auth.login'

    from app.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Register Blueprints
    from app.auth.routes import bp as auth_bp
    from app.main.routes import bp as main_bp
    from app.supervisor.routes import bp as supervisor_bp
    from app.admin.routes import bp as admin_bp
    from app.dot.routes import bp as dot_bp
    from app.tickets.routes import bp as tickets_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(supervisor_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(dot_bp)
    app.register_blueprint(tickets_bp)

    @app.route('/')
    def home():
        if current_user.is_authenticated:
            role = current_user.role
            if role == 'admin':
                return redirect(url_for('admin.dashboard'))
            elif role == 'supervisor':
                return redirect(url_for('supervisor.supervisor_home'))
            elif role == 'dot_officer':
                return redirect(url_for('dot.dot_home'))
            else:
                return redirect(url_for('main.player_home'))
        else:
            return redirect(url_for('auth.login'))

    @app.errorhandler(404)
    def page_not_found(e):
        message = getattr(e, 'description', 'Page not found.')
        return render_template('404.html', message=message), 404

    return app
