from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app import db
from app.models import User, Company, Ticket
from app.admin.utils import get_active_sessions  # Utility function to get active sessions

bp = Blueprint('admin', __name__, url_prefix='/admin')

from flask import abort
from flask_login import login_required

@bp.route('/tickets/')
@login_required
def tickets_placeholder():
    abort(404, description="Tickets page is being worked on.")

# Admin Home Panel
@bp.route('/')
@login_required
def admin_panel():
    if current_user.role not in ['admin', 'supervisor']:
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))
    users = User.query.all()
    return render_template('admin/admin.html', users=users)


# Admin Dashboard
@bp.route('/dashboard', endpoint='admin_dashboard')
@login_required
def admin_dashboard_view():
    if current_user.role not in ['admin', 'supervisor']:
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    sessions = get_active_sessions()
    companies = Company.query.all()
    users = User.query.all()
    tickets = Ticket.query.order_by(Ticket.date_issued.desc()).limit(50).all()
    total_balance = sum(user.balance for user in users)

    template = 'admin/dashboard.html'

    return render_template(
        template,
        active_sessions=sessions,
        companies=companies,
        users=users,
        tickets=tickets,
        total_balance=total_balance
    )


# Promote/Demote User Roles
@bp.route('/promote', methods=['POST'])
@login_required
def promote_user():
    if current_user.role != 'admin':
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    user_id = int(request.form['user_id'])
    new_role = request.form['new_role']
    user = User.query.get_or_404(user_id)
    user.role = new_role
    db.session.commit()

    flash(f"{user.username} promoted to {new_role}.")
    return redirect(url_for('admin.admin_dashboard'))


# Company Management
@bp.route('/companies', methods=['GET', 'POST'])
@login_required
def companies():
    if current_user.role != 'admin':
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    if request.method == 'POST':
        name = request.form.get('company_name')
        description = request.form.get('description')

        existing_company = Company.query.filter_by(name=name).first()
        if existing_company:
            flash('Company with this name already exists.')
            return redirect(url_for('admin.companies'))

        company = Company(name=name, description=description, owner_id=current_user.id)
        db.session.add(company)
        db.session.commit()
        flash("Company created successfully.")
        return redirect(url_for('admin.companies'))

    companies = Company.query.all()
    return render_template('admin/companies.html', companies=companies)


# Ticket Search Route
@bp.route('/tickets/search', methods=['GET'])
@login_required
def search_tickets():
    if current_user.role not in ['admin', 'supervisor']:
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    query = request.args.get('q', '').strip()
    tickets = []
    if query:
        tickets = Ticket.query.filter(
            (Ticket.reason.ilike(f'%{query}%')) |
            (Ticket.issued_to_username.ilike(f'%{query}%'))
        ).order_by(Ticket.date_issued.desc()).all()

    return render_template('admin/ticket_search_results.html', tickets=tickets, query=query)
@bp.route("/supervisor")
@login_required
def supervisor_panel():
    if not current_user.is_supervisor:
        return redirect(url_for('dashboard'))

    pending_permits = Permit.query.filter_by(status='pending').all()
    vehicles = Vehicle.query.filter_by(supervisor_id=current_user.id).all()

    return render_template("dot/supervisor_panel.html",
                           pending_permits=pending_permits,
                           vehicles=vehicles)