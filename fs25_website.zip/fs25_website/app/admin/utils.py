from datetime import datetime, timedelta
from collections import namedtuple
from app.models import User

SessionData = namedtuple('SessionData', ['username', 'role', 'login_time', 'duration', 'user_id'])

def get_active_sessions():
    active_threshold = datetime.utcnow() - timedelta(minutes=30)  # active within last 30 minutes
    active_users = User.query.filter(User.last_login != None).filter(User.last_login >= active_threshold).all()

    active_sessions = []
    now = datetime.utcnow()

    for user in active_users:
        login_time = user.last_login
        duration_td = now - login_time
        hours, remainder = divmod(duration_td.seconds, 3600)
        minutes, _ = divmod(remainder, 60)
        duration_str = f"{hours}h {minutes}m" if hours else f"{minutes}m"

        active_sessions.append(SessionData(
            username=user.username,
            role=user.role,
            login_time=login_time,
            duration=duration_str,
            user_id=user.id
        ))

    return active_sessions
