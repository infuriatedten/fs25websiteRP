from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from yourapp.models import Ticket, Permit, Vehicle  # adjust import to your project
from yourapp import db

bp = Blueprint('supervisor', __name__, url_prefix='/supervisor')

def get_tickets_for_supervisor(supervisor_id):
    return Ticket.query.filter_by(supervisor_id=supervisor_id).all()

def get_permits_for_supervisor(supervisor_id):
    return Permit.query.filter_by(supervisor_id=supervisor_id, status='pending').all()

def get_vehicles_for_supervisor(supervisor_id):
    return Vehicle.query.filter_by(supervisor_id=supervisor_id).all()

@bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'supervisor':
        flash("Access denied: Supervisors only.", "danger")
        return redirect(url_for('main.dashboard'))

    tickets = get_tickets_for_supervisor(current_user.id)
    permits = get_permits_for_supervisor(current_user.id)
    vehicles = get_vehicles_for_supervisor(current_user.id)

    return render_template(
        'supervisor/dashboard.html',
        tickets=tickets,
        permits=permits,
        vehicles=vehicles
    )
