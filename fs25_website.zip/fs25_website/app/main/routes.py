from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.models import User, Transaction, Vehicle
from datetime import datetime

bp = Blueprint('main', __name__, url_prefix='/player')

# Player Dashboard
@bp.route('/dashboard')
@login_required
def player_home():
    transactions = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.date.desc()).limit(10).all()
    vehicles = Vehicle.query.filter_by(owner_id=current_user.id).all()

    return render_template('player_home.html', 
                           user=current_user, 
                           transactions=transactions, 
                           vehicles=vehicles)

# Vehicle Registration Handler
@bp.route('/register-vehicle', methods=['POST'])
@login_required
def register_vehicle():
    name = request.form.get('vehicle_name')
    vehicle_type = request.form.get('vehicle_type')

    if not name or not vehicle_type:
        flash("All fields are required.", "danger")
        return redirect(url_for('main.player_home'))

    new_vehicle = Vehicle(
        owner_id=current_user.id,
        name=name,
        vehicle_type=vehicle_type,
        date_registered=datetime.utcnow()
    )
    db.session.add(new_vehicle)
    db.session.commit()

    flash(f"Vehicle '{name}' registered successfully!", "success")
    return redirect(url_for('main.player_home'))
