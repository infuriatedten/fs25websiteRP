from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user

bp = Blueprint('supervisor', __name__, url_prefix='/supervisor')

@bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'supervisor':
        flash("Access denied: Supervisors only.", "danger")
        return redirect(url_for('main.dashboard'))
    
    return render_template('supervisor/dashboard.html')
