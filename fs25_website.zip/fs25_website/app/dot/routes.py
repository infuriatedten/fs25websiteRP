from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models import Ticket, Permit, Vehicle, Inspection, User, Order
from app import db
from sqlalchemy import or_, and_

bp = Blueprint('dot', __name__, url_prefix='/dot')

@bp.route('/home')
@login_required
def dot_home():
    user_tickets = Ticket.query.filter_by(issued_to=current_user.id).all()
    user_permits = Permit.query.filter_by(owner_id=current_user.id).all()
    return render_template('dot_home.html', tickets=user_tickets, permits=user_permits)

@bp.route('/supervisor', methods=['GET', 'POST'])
@login_required
def supervisor_panel():
    if current_user.role not in ['dot_officer', 'supervisor', 'admin']:
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    query = Ticket.query
    search_user = request.args.get("user_id")
    search_status = request.args.get("status")
    search_term = request.args.get("search")

    if search_user:
        query = query.filter_by(issued_to=search_user)
    if search_status:
        query = query.filter_by(paid=(search_status == "paid"))
    if search_term:
        query = query.filter(Ticket.reason.ilike(f"%{search_term}%"))

    tickets = query.all()
    permits = Permit.query.filter_by(status='pending').all()
    vehicles = Vehicle.query.all()
    return render_template("dot/supervisor_panel.html", tickets=tickets, permits=permits, vehicles=vehicles)

@bp.route('/tickets', methods=['GET'])
@login_required
def view_tickets():
    if current_user.role not in ['admin', 'dot_officer']:
        flash("Access denied.")
        # Redirect to a safe page; change 'main.dashboard' if your main blueprint has a different endpoint
        return redirect(url_for('main.dashboard'))

    search = request.args.get('search', '')
    status_filter = request.args.get('status', '')

    query = Ticket.query.join(User, Ticket.issued_to == User.id)

    if search:
        query = query.filter(
            or_(
                Ticket.reason.ilike(f'%{search}%'),
                User.username.ilike(f'%{search}%')
            )
        )

    if status_filter in ['paid', 'unpaid']:
        query = query.filter_by(status=status_filter)

    tickets = query.order_by(Ticket.date_issued.desc()).all()
    return render_template('dot/tickets.html', tickets=tickets)

@bp.route("/issue_ticket", methods=["POST"])
@login_required
def issue_ticket():
    if current_user.role not in ['supervisor', 'admin']:
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    t = Ticket(
        reason=request.form['reason'],
        fine_amount=int(request.form['fine_amount']),
        issued_to=int(request.form['user_id'])
    )
    db.session.add(t)
    db.session.commit()
    flash("Ticket issued.")
    return redirect(url_for("dot.supervisor_panel"))

@bp.route("/permit/<int:permit_id>/approve")
@login_required
def approve_permit(permit_id):
    if current_user.role not in ['supervisor', 'admin']:
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    permit = Permit.query.get_or_404(permit_id)
    permit.status = "approved"
    db.session.commit()
    flash("Permit approved.")
    return redirect(url_for("dot.supervisor_panel"))

@bp.route("/permit/<int:permit_id>/reject")
@login_required
def reject_permit(permit_id):
    if current_user.role not in ['supervisor', 'admin']:
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    permit = Permit.query.get_or_404(permit_id)
    permit.status = "rejected"
    db.session.commit()
    flash("Permit rejected.")
    return redirect(url_for("dot.supervisor_panel"))

@bp.route("/log_inspection", methods=["POST"])
@login_required
def log_inspection():
    if current_user.role not in ['supervisor', 'admin']:
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    insp = Inspection(
        vehicle_id=int(request.form['vehicle_id']),
        passed=(request.form['passed'] == '1'),
        notes=request.form.get('notes', '')
    )
    db.session.add(insp)
    db.session.commit()
    flash("Inspection logged.")
    return redirect(url_for("dot.supervisor_panel"))

@bp.route('/ticket/<int:ticket_id>/orders', methods=['GET', 'POST'])
@login_required
def ticket_orders(ticket_id):
    ticket = Ticket.query.get_or_404(ticket_id)
    if not (current_user.role in ['admin', 'supervisor'] or ticket.issued_to == current_user.id):
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    if request.method == 'POST':
        order = Order(
            ticket_id=ticket.id,
            item_name=request.form['item_name'],
            quantity=int(request.form['quantity']),
            price_per_unit=float(request.form['price_per_unit'])
        )
        db.session.add(order)
        db.session.commit()
        flash("Order added.")
        return redirect(url_for('dot.ticket_orders', ticket_id=ticket.id))

    orders = Order.query.filter_by(ticket_id=ticket.id).all()
    return render_template('ticket_orders.html', ticket=ticket, orders=orders)

@bp.route('/inspections')
@login_required
def inspections():
    if current_user.role not in ['dot_officer', 'supervisor', 'admin']:
        flash("Access denied.")
        return redirect(url_for('dot.dot_home'))

    query = Inspection.query
    vehicle_id = request.args.get('vehicle_id')
    passed = request.args.get('passed')
    notes = request.args.get('notes')

    if vehicle_id:
        query = query.filter_by(vehicle_id=vehicle_id)
    if passed in ['0', '1']:
        query = query.filter_by(passed=(passed == '1'))
    if notes:
        query = query.filter(Inspection.notes.ilike(f"%{notes}%"))

    inspections = query.order_by(Inspection.timestamp.desc()).limit(100).all()
    return render_template('dot/inspections.html', inspections=inspections)

@bp.route('/permits')
@login_required
def permits():
    return "<h2>Permit Management (To Be Built)</h2>"
