from app import db
from flask_login import UserMixin
from datetime import datetime

class User(db.Model, UserMixin):
    __tablename__ = 'user'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='player')  # e.g. 'supervisor', 'dot_officer', 'admin', 'player'
    balance = db.Column(db.Float, default=0.0)

    last_login = db.Column(db.DateTime, default=None)
    login_time = db.Column(db.DateTime, default=None)
    logout_time = db.Column(db.DateTime, default=None)
    total_logged_hours = db.Column(db.Float, default=0.0)

    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=True)

    # Relationships
    vehicles = db.relationship('Vehicle', backref='owner', lazy=True, foreign_keys='Vehicle.owner_id')
    permits = db.relationship('Permit', backref='owner', lazy=True, foreign_keys='Permit.owner_id')
    tickets = db.relationship('Ticket', backref='issued_to_user', lazy=True, foreign_keys='Ticket.issued_to')
    
    # Supervisor relationships (tickets, permits, vehicles supervised)
    supervised_tickets = db.relationship('Ticket', backref='supervisor', lazy=True, foreign_keys='Ticket.supervisor_id')
    supervised_permits = db.relationship('Permit', backref='supervisor', lazy=True, foreign_keys='Permit.supervisor_id')
    supervised_vehicles = db.relationship('Vehicle', backref='supervisor', lazy=True, foreign_keys='Vehicle.supervisor_id')

    def __repr__(self):
        return f'<User {self.username} ({self.role})>'

class Company(db.Model):
    __tablename__ = 'company'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)

    users = db.relationship('User', backref='company', lazy=True)
    tickets = db.relationship('Ticket', backref='company', lazy=True)

class Vehicle(db.Model):
    __tablename__ = 'vehicle'

    id = db.Column(db.Integer, primary_key=True)
    plate = db.Column(db.String(20), unique=True, nullable=True)
    name = db.Column(db.String(100), nullable=False)
    vehicle_type = db.Column(db.String(100), nullable=False)
    date_registered = db.Column(db.DateTime, default=datetime.utcnow)

    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    supervisor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

    inspections = db.relationship('Inspection', backref='vehicle', lazy=True)

    def __repr__(self):
        return f'<Vehicle {self.plate or self.name}>'


class Inspection(db.Model):
    __tablename__ = 'inspection'

    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    passed = db.Column(db.Boolean, nullable=False)
    notes = db.Column(db.Text, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Inspection VehicleID:{self.vehicle_id} Passed:{self.passed} at {self.timestamp}>'
class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(255), nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)

class Ticket(db.Model):
    __tablename__ = 'ticket'

    id = db.Column(db.Integer, primary_key=True)
    reason = db.Column(db.String(200), nullable=True)
    fine_amount = db.Column(db.Float, default=0.0)
    issued_to = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=True)
    paid = db.Column(db.Boolean, default=False)
    date_issued = db.Column(db.DateTime, default=datetime.utcnow)

    supervisor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

    items = db.relationship('TicketItem', backref='ticket', lazy=True)

    @property
    def total_price(self):
        return self.fine_amount + sum(item.total_price for item in self.items)

    def __repr__(self):
        return f'<Ticket #{self.id} to User {self.issued_to}, Paid: {self.paid}>'

class TicketItem(db.Model):
    __tablename__ = 'ticket_item'

    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('ticket.id'), nullable=False)
    material_name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price_per_unit = db.Column(db.Float, nullable=False)

    @property
    def total_price(self):
        return self.quantity * self.price_per_unit

    def __repr__(self):
        return f'<TicketItem {self.material_name} x{self.quantity} @ {self.price_per_unit}>'

class Permit(db.Model):
    __tablename__ = 'permit'

    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='pending')  # e.g. pending, approved, denied
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    supervisor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

    def __repr__(self):
        return f'<Permit #{self.id} Type: {self.type} Status: {self.status}>'

class Order(db.Model):
    __tablename__ = 'order'

    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('ticket.id'), nullable=False)
    item_name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price_per_unit = db.Column(db.Float, nullable=False)

    @property
    def total_price(self):
        return self.quantity * self.price_per_unit

    def __repr__(self):
        return f'<Order {self.item_name} x{self.quantity} @ {self.price_per_unit}>'
